//
//  ViewController.swift
//  LeaveList
//
//  Created by Dmitry on 14/7/16.
//  Copyright © 2016 Dmitry Klimkin. All rights reserved.
//

import UIKit
import RealmSwift
import EZSwiftExtensions
import Keyboardy

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,
                      ListEntryCellDelegate, KeyboardStateDelegate {
    
    private let tableView = UITableView(frame: CGRectZero, style: .Plain)
    private var items: Results<ListEntry>?
    private var lastVisibleView: UIView?
    private var newContentViewCenterPoint = CGPointZero
    
    private var refreshControl: UIRefreshControl!
    
    private let cellid = "ListEntryCellId"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor = UIColor.redColor()
        
        tableView.backgroundColor = UIColor.whiteColor()
        tableView.frame = view.bounds
        tableView.registerClass(ListEntryCell.self, forCellReuseIdentifier: cellid)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = layout.tableViewCellHeight
        tableView.bounces = true
        
        refreshControl = UIRefreshControl()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to reload")
        refreshControl.addTarget(self, action: #selector(ViewController.triggerRefresh), forControlEvents: UIControlEvents.ValueChanged)
        
        tableView.addSubview(refreshControl)
        
        view.addSubview(tableView)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add",
                                                            style: .Plain,
                                                            target: self,
                                                            action: #selector(ViewController.onAddButtonTap))
        ez.runThisInMainThread { 
            self.registerForKeyboardNotifications(self)
            self.reloadData()
        }
    }
    
    deinit {
        unregisterFromKeyboardNotifications()
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let listEntry = items![indexPath.row]

        return ListEntryCell.heightForText(listEntry.textDescription)
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let itemsValue = items {
            return itemsValue.count
        } else {
            return 0
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(cellid, forIndexPath: indexPath) as! ListEntryCell
        
        let listEntry = items![indexPath.row]
        
        cell.title = listEntry.textDescription
        cell.timestamp = listEntry.lastActionDate
        cell.indexPath = indexPath
        cell.delegate = self
        cell.selectionStyle = .None
        
        return cell
    }

    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        return .Delete
    }
    
    func triggerRefresh() {
        print ("Refreshing...")
        reloadData()
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        guard editingStyle == .Delete else {
            return
        }
        
        let listEntry = items![indexPath.row].copyToSave()

        tableView.beginUpdates()
        
        listEntry.isDeleted = true
        
        Model.save(listEntry)

        tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)

        tableView.endUpdates()
        
//        ez.runThisAfterDelay(seconds: 1.0) { 
//            self.reloadData()
//        }
    }
    
    func markEntryDone(indexPath: NSIndexPath) {
        let listEntry = items![indexPath.row].copyToSave() as! ListEntry
        
        listEntry.lastActionDate = NSDate()
        
        Model.save(listEntry)
        
        tableView.reloadRowsAtIndexPaths([indexPath], withRowAnimation: .Automatic)
    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]?  {
        // add the action button you want to show when swiping on tableView's cell , in this case add the delete button.
        let deleteAction = UITableViewRowAction(style: .Destructive, title: "Delete", handler: { (action , indexPath) -> Void in
            self.tableView(tableView, commitEditingStyle: .Delete, forRowAtIndexPath: indexPath)
        })
        
        let markDoneAction = UITableViewRowAction(style: .Normal, title: "Mark Done", handler: { (action , indexPath) -> Void in
            self.markEntryDone(indexPath)
        })
        
        // You can set its properties like normal button
        deleteAction.backgroundColor = UIColor.redColor()
        markDoneAction.backgroundColor = UIColor.darkGrayColor()
        
        return [deleteAction, markDoneAction]
    }
    
    func reloadData() {
        items = ListEntry.loadAllEntries()
        
        tableView.reloadData()
        refreshControl.endRefreshing()
    }

    func onAddButtonTap() {
        let newRecord = ListEntry()
        
        newRecord.textDescription = ""
        newRecord.lastActionDate = NSDate.distantPast()
        
        Model.save(newRecord)
        
        print(newRecord)
        
        reloadData()
    }
    
    func didUpdateDescriptionForCellAtIndexPath(indexPath: NSIndexPath, text: String) {
        let listEntry = items![indexPath.row].copyToSave() as! ListEntry
        
        listEntry.textDescription = text
        
        Model.save(listEntry)
    }
    
    func keyboardWillTransition(state: KeyboardState) {
//        guard let lastVisibleView = self.lastVisibleView else {
//            return
//        }
//        
//        let contentView = tableView
//        
        /*
        // keyboard will show or hide
        newContentViewCenterPoint = contentView.center
        
        switch state {
        case .ActiveWithHeight(let height):
            let visibleHeight = contentView.frame.size.height - height
            let lastVisiblePointY = lastVisibleView.frame.origin.y + lastVisibleView.frame.size.height
            
            if (visibleOffset == 0.0) && ((lastVisiblePointY + visibleMargin) > visibleHeight) {
                
                visibleOffset = lastVisiblePointY - visibleHeight + visibleMargin
                
                newContentViewCenterPoint.y -= visibleOffset
            }
            
            logoView.alpha = 0.0
            
            break
        case .Hidden:
            visibleOffset = 0.0
            logoView.alpha = 1.0
            
            newContentViewCenterPoint = CGPointMake(Config.ScreenWidth / 2, Config.ScreenHeight / 2)
            break
        }
 */
    }
    
    func keyboardTransitionAnimation(state: KeyboardState) {
//        contentView.center = newContentViewCenterPoint
    }
    
    func keyboardDidTransition(state: KeyboardState) {
        // keyboard animation finished
    }
}

