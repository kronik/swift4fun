//
//  Config.swift
//  LeaveList
//
//  Created by Dmitry on 15/7/16.
//  Copyright © 2016 Dmitry Klimkin. All rights reserved.
//

import Foundation

struct Config {
    static let AppStoreAppId               = "00000000000"
}