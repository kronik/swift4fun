//: Please build the scheme 'RealmPlayground' first
import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

import Realm
import RealmSwift

let realmDbSchemaVersion: UInt64 = 3

var config = Realm.Configuration(
    schemaVersion: realmDbSchemaVersion,
    migrationBlock: {(migration: Migration, oldSchemaVersion: UInt64) in
        if oldSchemaVersion < 1 { }
    }
)
Realm.Configuration.defaultConfiguration = config


protocol Indentifier {
    func getSKU() -> String
}

class OrderA: Object, Indentifier {
    dynamic var key = ""
    dynamic var title = ""
    dynamic var info = ""
    dynamic var quantity: Int = 0
    dynamic var createdAt = NSDate()
    dynamic var isDeleted = false
    
    func getSKU() -> String {
        return "SKU-\(key)"
    }
    
    override class func primaryKey() -> String? {
        return "key"
    }
}

func selectByKey(key: String) {
    let filter = NSPredicate(format: "key == %@ AND isDeleted == false", key)
    let realm = try! Realm()
    
    let results = realm.objects(OrderA).filter(filter).sorted("createdAt", ascending: true)

//    print(results)

    print(results[0].getSKU())
}

var order1 = OrderA()

order1.key = "1"
order1.title = "Socks"
order1.info = "Red socks"
order1.quantity = 10

var order2 = OrderA()

order2.key = "2"
order2.title = "Socks"
order2.info = "Blue socks"
order2.quantity = 1000
order2.isDeleted = false

let realm = try! Realm()

try! realm.write {
    realm.add(order1, update: true)
    realm.add(order2, update: true)
}

//selectByKey("2")


try! realm.write {
    order1.isDeleted = true
}

selectByKey("2")

